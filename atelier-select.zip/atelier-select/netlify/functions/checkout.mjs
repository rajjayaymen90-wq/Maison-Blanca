export { checkout as default } from '../../server/handlers.mjs';
