export { session as default } from '../../server/handlers.mjs';
