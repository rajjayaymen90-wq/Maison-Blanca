import { checkout } from '../server/handlers.mjs';
import { vercelAdapter } from '../server/vercel-adapter.mjs';
export const config = { api: { bodyParser: false } };
export default vercelAdapter(checkout);
