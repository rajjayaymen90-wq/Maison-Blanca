import { Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight, ShoppingBag, LockKeyhole } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { money, totals, shop } from '../lib/catalog';
import CartItems from '../components/CartItems';
import OrderSummary from '../components/OrderSummary';
import SEO from '../components/SEO';
export default function Cart() {
  const { cart, count, promo } = useShop();
  const remaining = Math.max(0,shop.freeShippingThreshold - totals(cart,promo).merchandise);
  return <div className="container transaction-page"><SEO title="Votre panier" noindex/><div className="breadcrumbs"><Link to="/">Accueil</Link><span>/</span><span>Panier</span></div><div className="page-heading"><p className="eyebrow">VOTRE SÉLECTION</p><h1>Les bonnes pièces,<br/>au bon endroit.</h1><p>{count} article{count > 1 ? 's' : ''} dans votre panier.</p></div>{cart.length ? <div className="transaction-layout"><div><div className="shipping-progress"><p>{remaining ? `Plus que ${money(remaining)} pour la livraison standard offerte.` : 'Votre livraison standard est offerte.'}</p><progress max={shop.freeShippingThreshold} value={Math.min(shop.freeShippingThreshold,totals(cart,promo).merchandise)} aria-label="Progression vers la livraison offerte"/></div><CartItems/><Link className="text-link continue-shopping" to="/boutique"><ArrowLeft size={16}/>Continuer la sélection</Link></div><div><OrderSummary><Link className="button full" to="/commande">Passer commande <ArrowRight size={18}/></Link><p className="secure-note"><LockKeyhole size={14}/>Paiement sécurisé · Carte bancaire</p></OrderSummary><p className="promo-hint">Un premier coup de cœur ?<br/>Le code <strong>BIENVENUE10</strong> vous offre 10 %.</p></div></div> : <div className="empty-state"><ShoppingBag size={42}/><h2>Votre panier attend ses essentiels.</h2><p>T-shirts, pulls ou sweats : trouvez les pièces que vous aurez envie de porter chaque jour.</p><Link className="button" to="/boutique">Explorer la boutique <ArrowRight size={18}/></Link></div>}</div>;
}
