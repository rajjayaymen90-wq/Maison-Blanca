import { useRef, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, LockKeyhole, Truck } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { money, productById, shop, totals } from '../lib/catalog';
import { saveOrder } from '../lib/storage';
import OrderSummary from '../components/OrderSummary';
import SEO from '../components/SEO';
const demo = import.meta.env.VITE_DEMO_MODE !== 'false';
export default function Checkout() {
  const { cart, promo, user, clearPurchased, notify } = useShop();
  const [delivery, setDelivery] = useState('standard');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const busyRef = useRef(false);
  const attempt = useRef(null);
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const [customer, setCustomer] = useState({ firstName:user?.name || '', lastName:'', email:user?.email || '', phone:'', address:'', address2:'', postalCode:'', city:'', country:'FR' });
  function field(name, label, type='text', autoComplete=name, optional=false) { return <label className={`field field-${name}`} key={name}><span>{label}{optional && <small> (facultatif)</small>}</span><input name={name} type={type} autoComplete={autoComplete} required={!optional} value={customer[name]} maxLength={name === 'email' ? 254 : 150} onChange={e => setCustomer(c => ({...c,[name]:e.target.value}))} {...(name === 'phone' ? { pattern:'[+0-9\\s.\\(\\)\\-]{6,30}', title:'Saisissez un numéro de téléphone valide (6 à 30 caractères).' } : name === 'postalCode' ? { pattern:'[A-Za-z0-9 \\-]{3,12}', title:'Saisissez un code postal valide.' } : {})}/></label>; }
  async function submit(e) {
    e.preventDefault();
    if (busyRef.current || !cart.length) return;
    if (Object.entries(customer).some(([k,v]) => k !== 'address2' && !v.trim())) { setError('Complétez toutes vos coordonnées.'); return; }
    if (!/^[+\d\s().-]{6,30}$/.test(customer.phone.trim())) { setError('Saisissez un numéro de téléphone valide.'); return; }
    busyRef.current = true; setBusy(true); setError('');
    const snapshot = { items:cart.map(i => ({...i})), promo, delivery, customer:Object.fromEntries(Object.entries(customer).map(([k,v]) => [k,v.trim()])) };
    const fingerprint = JSON.stringify(snapshot);
    if (attempt.current?.fingerprint !== fingerprint) attempt.current = { fingerprint, attemptId:crypto.randomUUID(), verificationToken:crypto.randomUUID() };
    try {
      if (demo) {
        const id = `demo-${attempt.current.attemptId}`;
        const order = { ...snapshot, id, number:`AS-${id.slice(-8).toUpperCase()}`, date:new Date().toISOString(), ...totals(snapshot.items,promo,delivery), userId:user?.id || null, email:customer.email.trim().toLowerCase(), mode:'demo', items:snapshot.items.map(i => ({...i,name:productById(i.id).name,brand:productById(i.id).brand,price:productById(i.id).price,image:productById(i.id).images[0]})) };
        if (!saveOrder(order)) throw new Error('L’enregistrement local a échoué. Libérez de l’espace ou autorisez le stockage de ce navigateur.');
        clearPurchased(snapshot.items);
        navigate(`/confirmation?commande=${encodeURIComponent(id)}`);
      } else {
        const { attemptId, verificationToken } = attempt.current;
        const pending = { ...snapshot, userId:user?.id || null, attemptId, verificationToken };
        try { sessionStorage.setItem('atelier:pending', JSON.stringify(pending)); } catch { throw new Error('Autorisez le stockage de session pour pouvoir vérifier votre paiement au retour.'); }
        const response = await fetch('/api/checkout', { method:'POST', headers:{'Content-Type':'application/json'},body:JSON.stringify({...snapshot,attemptId,verificationToken}) });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || 'Le paiement n’est pas disponible. Vérifiez la configuration de votre serveur.');
        if (!data.url || new URL(data.url).hostname !== 'checkout.stripe.com') throw new Error('Lien de paiement Stripe invalide.');
        sessionStorage.setItem('atelier:pending', JSON.stringify({...pending,sessionId:data.id}));
        window.location.assign(data.url);
      }
    } catch (err) { setError(err.message); busyRef.current=false;setBusy(false); }
  }
  if (!cart.length) return <div className="container empty-state not-found"><SEO title="Commande" noindex/><h1>Votre panier est vide.</h1><p>Ajoutez votre première pièce avant de passer commande.</p><Link to="/boutique" className="button">Découvrir la sélection <ArrowRight size={18}/></Link></div>;
  return <div className="container transaction-page"><SEO title="Finaliser ma commande" noindex/><div className="breadcrumbs"><Link to="/panier">Panier</Link><span>/</span><span>Livraison & paiement</span></div><div className="page-heading"><p className="eyebrow">LA DERNIÈRE ÉTAPE</p><h1>Bientôt chez vous.</h1><p>Quelques détails, et vos essentiels prennent la route.</p></div>{demo && <p className="demo-notice">Mode démo : cette commande est simulée, sans paiement ni expédition. Utilisez des coordonnées fictives.</p>}{params.has('annule') && <p className="demo-notice">Le paiement a été annulé. Votre panier est conservé ; vous pouvez reprendre votre commande.</p>}<div className="transaction-layout checkout-layout"><form id="checkout-form" onSubmit={submit} className="checkout-form"><section><h2><span>01</span>Vos coordonnées</h2>{!user && <p className="form-intro">Déjà chez vous ? <Link to="/compte?retour=commande">Connectez-vous</Link> pour retrouver cette commande dans votre compte.</p>}<div className="form-grid">{field('email','Adresse e-mail','email','email')}{field('phone','Téléphone','tel','tel')}{field('firstName','Prénom','text','given-name')}{field('lastName','Nom','text','family-name')}</div></section><section><h2><span>02</span>Votre adresse de livraison</h2><div className="form-grid">{field('address','Adresse','text','address-line1')}{field('address2','Appartement, bâtiment…','text','address-line2',true)}{field('postalCode','Code postal','text','postal-code')}{field('city','Ville','text','address-level2')}<label className="field field-country"><span>Pays</span><select value={customer.country} onChange={e => setCustomer(c => ({...c,country:e.target.value}))} autoComplete="country"><option value="FR">France</option><option value="BE">Belgique</option><option value="LU">Luxembourg</option><option value="DE">Allemagne</option><option value="ES">Espagne</option><option value="IT">Italie</option><option value="NL">Pays-Bas</option><option value="PT">Portugal</option></select></label></div></section><section><h2><span>03</span>À votre rythme</h2><div className="delivery-options">{Object.entries(shop.shipping).map(([key,d]) => <label key={key} className={delivery === key ? 'delivery-option selected' : 'delivery-option'}><input type="radio" name="delivery" checked={delivery === key} onChange={() => setDelivery(key)} value={key}/><Truck size={20}/><span><strong>{d.label}</strong><small>{d.delay}</small></span><b>{totals(cart,promo,key).shipping ? money(totals(cart,promo,key).shipping) : 'Offerte'}</b></label>)}</div></section>{error && <p className="form-error" role="alert">{error}</p>}<Link to="/panier" className="text-link"><ArrowLeft size={15}/>Retour au panier</Link></form><aside><div className="checkout-mini-items">{cart.map(i => { const p=productById(i.id); return <div key={`${i.id}-${i.size}-${i.color}`}><img src={p.images[0]} alt={p.name} width="55" height="65"/><span><b>{p.name}</b><small>{i.color} · {i.size} · Qté {i.quantity}</small></span><strong>{money(p.price*i.quantity)}</strong></div>; })}</div><OrderSummary delivery={delivery}><button type="submit" form="checkout-form" disabled={busy} className="button full">{busy ? 'Un instant…' : demo ? 'Confirmer la commande démo' : 'Payer avec Stripe'}{!busy && <ArrowRight size={17}/>}</button><p className="secure-note"><LockKeyhole size={14}/>{demo ? 'Aucun montant ne sera débité' : 'Redirection vers le paiement sécurisé Stripe'}</p></OrderSummary><p className="checkout-policy">En poursuivant, vous confirmez les informations de livraison. <Link to="/informations">Informations sur la boutique démo</Link>.</p></aside></div></div>;
}
