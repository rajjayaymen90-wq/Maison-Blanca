import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import SEO from '../components/SEO';
export default function NotFound() { return <div className="container empty-state not-found"><SEO title="Page introuvable" noindex/><span className="eyebrow">404 · CETTE PAGE A FILÉ</span><h1>Reprenons le fil.</h1><p>Cette page ou cette pièce n’est plus disponible.</p><Link to="/boutique" className="button">Retour à la boutique <ArrowRight size={18}/></Link></div>; }
