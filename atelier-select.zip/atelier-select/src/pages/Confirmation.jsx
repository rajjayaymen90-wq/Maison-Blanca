import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowRight, Check, PackageCheck } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { money, productById, shop } from '../lib/catalog';
import { getOrders, saveOrder } from '../lib/storage';
import SEO from '../components/SEO';
export default function Confirmation() {
  const [params] = useSearchParams();
  const { clearPurchased } = useShop();
  const id = params.get('commande');
  const sessionId = params.get('session_id');
  const [order,setOrder] = useState(() => getOrders().find(o => o.id === (id || sessionId)) || null);
  const [error,setError] = useState('');
  const [loading,setLoading] = useState(Boolean(sessionId && !order));
  const [retry,setRetry] = useState(0);
  useEffect(() => {
    if (order || !sessionId) return;
    let cancelled=false;
    async function verify() {
      setLoading(true);setError('');
      try {
        let pending;
        try { pending=JSON.parse(sessionStorage.getItem('atelier:pending')); } catch {}
        if (!pending?.verificationToken || pending.sessionId !== sessionId) throw new Error('Cette commande doit être vérifiée depuis le navigateur qui a initié le paiement. Retrouvez la transaction dans votre tableau de bord Stripe si nécessaire.');
        const response=await fetch(`/api/session?session_id=${encodeURIComponent(sessionId)}`,{headers:{Authorization:`Bearer ${pending.verificationToken}`}});
        const result=await response.json();
        if (!response.ok) throw new Error(result.error || 'La vérification du paiement a échoué.');
        if (!result.paid) throw new Error('Votre paiement est en cours de validation. Attendez quelques instants puis réessayez.');
        const verified = {...result,userId:pending.userId,email:pending.customer.email.toLowerCase(),customer:pending.customer};
        if (cancelled) return;
        if (!saveOrder(verified)) throw new Error('Le paiement est confirmé mais le stockage local est plein. Libérez de l’espace puis relancez la vérification.');
        clearPurchased(pending.items);setOrder(verified);
      } catch(err) { if (!cancelled) setError(err.message); }
      finally { if (!cancelled) setLoading(false); }
    }
    verify();return () => { cancelled=true; };
  },[sessionId,retry]);
  if (!order) return <div className="container empty-state not-found"><SEO title="Confirmation de commande" noindex/><PackageCheck size={38}/><h1>{loading ? 'Un dernier instant…' : 'Vérifions votre commande.'}</h1><p role={error ? 'alert' : 'status'}>{loading ? 'Nous vérifions la confirmation du paiement.' : error || 'Aucune commande ne correspond à ce lien.'}</p>{sessionId && !loading && <button className="button" onClick={() => setRetry(n => n+1)}>Relancer la vérification</button>}<Link to="/boutique" className="text-link">Retour à la boutique</Link></div>;
  return <div className="container confirmation-page"><SEO title={`Commande ${order.number}`} noindex/><div className="confirmation-heading"><span className="success-icon"><Check size={28}/></span><p className="eyebrow">{order.mode === 'demo' ? 'COMMANDE DÉMO ENREGISTRÉE' : 'PAIEMENT DE TEST CONFIRMÉ'}</p><h1>Bien choisi.<br/>Merci à vous.</h1><p>Votre sélection a été enregistrée sous le numéro <strong>{order.number}</strong>.</p><span className="confirmation-status">{order.mode === 'demo' ? 'Simulation · Aucun paiement ni envoi' : 'Stripe · Transaction en mode test'}</span></div><div className="confirmation-card"><div className="confirmation-card-head"><h2>Votre sélection</h2><span>{new Date(order.date).toLocaleDateString('fr-FR')}</span></div>{order.items.map((i,index) => { const p=productById(i.id);return <div className="confirmation-item" key={index}>{(i.image || p?.images[0]) && <img src={i.image || p.images[0]} alt={i.name} width="65" height="80"/>}<div><strong>{i.name}</strong><p>{i.color} / {i.size} · Quantité {i.quantity}</p></div><span>{money(i.price*i.quantity)}</span></div>; })}{order.discount > 0 && <div className="summary-row discount"><span>Réduction {order.promo}</span><span>−{money(order.discount)}</span></div>}<div className="summary-row"><span>{shop.shipping[order.delivery]?.label || 'Livraison'}</span><span>{order.shipping ? money(order.shipping) : 'Offerte'}</span></div><div className="summary-row summary-total"><span>Total {order.mode === 'demo' ? 'simulé' : 'payé en test'}</span><strong>{money(order.total)}</strong></div>{order.customer && <div className="confirmation-address"><div><h3>Livraison</h3><p>{order.customer.firstName} {order.customer.lastName}<br/>{order.customer.address}{order.customer.address2 && <><br/>{order.customer.address2}</>}<br/>{order.customer.postalCode} {order.customer.city} · {order.customer.country}</p></div><div><h3>Contact</h3><p>{order.customer.email}<br/>{order.customer.phone}</p></div></div>}</div><div className="confirmation-actions"><Link to="/boutique" className="button">Poursuivre la découverte <ArrowRight size={18}/></Link><Link to="/compte" className="text-link">Voir mon compte</Link></div></div>;
}
