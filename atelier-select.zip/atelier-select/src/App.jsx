import { Route, Routes } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Catalog from './pages/Catalog';
import Product from './pages/Product';
import NotFound from './pages/NotFound';
import { lazy, Suspense } from 'react';
const Cart = lazy(() => import('./pages/Cart'));
const Checkout = lazy(() => import('./pages/Checkout'));
const Confirmation = lazy(() => import('./pages/Confirmation'));
const Account = lazy(() => import('./pages/Account'));
const Contact = lazy(() => import('./pages/Contact'));
const Categories = lazy(() => import('./pages/Categories'));
const Information = lazy(() => import('./pages/Information'));
export default function App() { return <Suspense fallback={<div className="empty-state" role="status">Votre sélection arrive…</div>}><Routes><Route element={<Layout/>}><Route index element={<Home/>}/><Route path="boutique" element={<Catalog/>}/><Route path="produit/:slug" element={<Product/>}/><Route path="categories" element={<Categories/>}/><Route path="panier" element={<Cart/>}/><Route path="commande" element={<Checkout/>}/><Route path="confirmation" element={<Confirmation/>}/><Route path="compte" element={<Account/>}/><Route path="contact" element={<Contact/>}/><Route path="informations" element={<Information/>}/><Route path="*" element={<NotFound/>}/></Route></Routes></Suspense>; }
