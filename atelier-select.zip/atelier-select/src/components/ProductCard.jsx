import { ArrowUpRight, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';
import { money } from '../lib/catalog';
export default function ProductCard({ product: p }) {
  return <article className="product-card">
    <Link className="product-image" to={`/produit/${p.slug}`} aria-label={`Voir ${p.name}, ${p.brand}`}>
      <img src={p.images[0]} alt={`${p.name} — ${p.brand}`} loading="lazy" width="600" height="750" />
      {p.oldPrice ? <span className="badge sale">−{Math.round((1 - p.price / p.oldPrice) * 100)} %</span> : p.isNew && <span className="badge">Nouveau</span>}
      <span className="product-plus"><Plus size={20} /></span><span className="product-hover">Découvrir la pièce <ArrowUpRight size={16}/></span>
    </Link>
    <div className="product-meta"><p>{p.brand}</p><span>{p.colors.length} couleurs</span></div>
    <div className="product-title"><Link to={`/produit/${p.slug}`}>{p.name}</Link><div>{p.oldPrice && <del>{money(p.oldPrice)}</del>}<strong>{money(p.price)}</strong></div></div>
    <div className="swatch-list" aria-label="Couleurs disponibles">{p.colors.map(c => <span key={c.name} title={c.name} style={{ backgroundColor: c.hex }} />)}</div>
  </article>;
}
