import { useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { ArrowRight, ArrowUpRight, Check, Menu, PackageCheck, RotateCcw, Search, ShieldCheck, ShoppingBag, Truck, UserRound, X } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { money, totals } from '../lib/catalog';
import Modal from './Modal';
import CartItems from './CartItems';
import WebMCP from './WebMCP';
export default function Layout() {
  const { count, cart, promo, cartOpen, setCartOpen, toast } = useShop();
  const [menu, setMenu] = useState(false);
  const { pathname } = useLocation();
  useEffect(() => { setMenu(false); window.scrollTo(0, 0); }, [pathname]);
  return <><WebMCP/><a href="#main-content" className="skip-link">Aller au contenu</a><div className="announcement">Une sélection qui fait la différence. <span>Livraison offerte dès 100 €</span><ArrowUpRight size={13}/></div>
    <header className="header"><div className="header-inner"><button className="icon-button mobile-menu" onClick={() => setMenu(!menu)} aria-label={menu ? 'Fermer le menu' : 'Ouvrir le menu'} aria-expanded={menu}>{menu ? <X/> : <Menu/>}</button>
      <Link to="/" className="wordmark" aria-label="Atelier Select, accueil">ATELIER<span>SELECT</span><i>®</i></Link>
      <nav className={menu ? 'main-nav open' : 'main-nav'} aria-label="Navigation principale"><NavLink to="/" end>Accueil</NavLink><NavLink to="/boutique">Boutique</NavLink><NavLink to="/categories">Catégories</NavLink><NavLink to="/contact">Contact</NavLink></nav>
      <div className="header-actions"><Link className="icon-button search-link" to="/boutique?recherche=" aria-label="Rechercher une pièce"><Search size={20}/></Link><Link className="icon-button" to="/compte" aria-label="Mon compte"><UserRound size={20}/></Link><button className="cart-trigger" aria-label={`Ouvrir le panier, ${count} article${count > 1 ? 's' : ''}`} onClick={() => setCartOpen(true)}><ShoppingBag size={20}/><span className="cart-label">Panier</span><span className="cart-count">{count}</span></button></div>
    </div></header>
    <main id="main-content"><Outlet/></main>
    <section className="service-strip" aria-label="Nos services"><div><Truck/><span><strong>Livraison offerte dès 100 €</strong><small>Standard en 3 à 5 jours ouvrés</small></span></div><div><RotateCcw/><span><strong>Retours sous 30 jours</strong><small>Prenez le temps de choisir</small></span></div><div><ShieldCheck/><span><strong>Paiement sécurisé</strong><small>Par carte bancaire avec Stripe</small></span></div></section>
    <footer className="footer"><div className="footer-main"><div><Link to="/" className="wordmark">ATELIER<span>SELECT</span><i>®</i></Link><p>Moins de pièces. Plus de caractère.<br/>Un vestiaire choisi, pour tous les jours.</p></div><div><h3>La sélection</h3><Link to="/boutique?selection=nouveautes">Nouveautés</Link><Link to="/boutique?categorie=t-shirts">T-shirts</Link><Link to="/boutique?categorie=pulls">Pulls & sweats</Link><Link to="/boutique?selection=promotions">Dernières pièces</Link></div><div><h3>À votre service</h3><Link to="/contact">Nous contacter</Link><Link to="/contact#livraison">Livraison & retours</Link><Link to="/compte">Mon compte</Link><Link to="/panier">Mon panier</Link></div><div className="footer-note"><span className="eyebrow">LE SENS DU DÉTAIL</span><p>Des marques singulières.<br/>Des essentiels bien choisis.</p><Link to="/boutique" className="text-link">Trouver votre prochaine pièce <ArrowUpRight size={16}/></Link></div></div><div className="footer-bottom"><span>© {new Date().getFullYear()} ATELIER SELECT</span><span>Collection démo · Visuels d’illustration</span><Link to="/informations">Informations & confidentialité</Link><span>France · EUR €</span></div></footer>
    {toast && <div className="toast" role="status"><Check size={18}/>{toast}</div>}
    {cartOpen && <Modal title={`Votre panier (${count})`} onClose={() => setCartOpen(false)} drawer>{cart.length ? <><p className="drawer-note"><PackageCheck size={17}/>{totals(cart, promo).merchandise >= 10000 ? 'Votre livraison standard est offerte.' : `Encore ${money(10000 - totals(cart, promo).merchandise)} pour la livraison offerte.`}</p><CartItems/><div className="drawer-total"><span>Sous-total{promo && ' après réduction'}</span><strong>{money(totals(cart, promo).merchandise)}</strong></div><Link className="button full" to="/panier" onClick={() => setCartOpen(false)}>Voir mon panier <ArrowRight size={18}/></Link><Link className="button secondary full" to="/commande" onClick={() => setCartOpen(false)}>Passer commande</Link></> : <div className="empty-state"><ShoppingBag size={38}/><h3>Votre sélection commence ici.</h3><p>Les essentiels de votre prochain quotidien vous attendent.</p><Link className="button" to="/boutique" onClick={() => setCartOpen(false)}>Explorer la boutique <ArrowRight size={18}/></Link></div>}</Modal>}
  </>;
}
