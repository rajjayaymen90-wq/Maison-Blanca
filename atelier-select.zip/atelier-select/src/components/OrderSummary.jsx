import { useState } from 'react';
import { Tag, X } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { money, shop, totals } from '../lib/catalog';
export default function OrderSummary({ delivery = 'standard', children, editablePromo = true }) {
  const { cart, promo, setPromo } = useShop();
  const [code, setCode] = useState(promo);
  const [message, setMessage] = useState('');
  const t = totals(cart, promo, delivery);
  function apply(e) { e.preventDefault(); const normalized = code.trim().toUpperCase(); if (shop.promos[normalized]) { setPromo(normalized); setMessage('Code appliqué à votre sélection.'); } else { setMessage('Ce code n’est pas valide. Essayez BIENVENUE10.'); } }
  return <div className="order-summary"><h2>Votre récapitulatif</h2><div className="summary-row"><span>Sous-total</span><span>{money(t.subtotal)}</span></div>{t.discount > 0 && <div className="summary-row discount"><span>Réduction {promo}</span><span>−{money(t.discount)}</span></div>}<div className="summary-row"><span>Livraison {delivery === 'express' ? 'express' : 'standard'}</span><span>{t.shipping ? money(t.shipping) : 'Offerte'}</span></div>
    {editablePromo && <div className="promo-area">{promo ? <div className="applied-promo"><Tag size={16}/>{promo}<button className="icon-button" aria-label="Retirer le code promo" onClick={() => { setPromo(''); setCode(''); setMessage(''); }}><X size={16}/></button></div> : <form onSubmit={apply} className="promo-form"><label className="sr-only" htmlFor="promo-code">Code promo</label><input id="promo-code" value={code} onChange={e => setCode(e.target.value)} placeholder="Code promo" maxLength={40}/><button type="submit">Appliquer</button></form>}{message && <p className="form-message" role="status">{message}</p>}</div>}
    <div className="summary-row summary-total"><span>Total</span><strong>{money(t.total)}</strong></div><p className="tax-note">Taxes incluses · Frais de livraison compris</p>{children}</div>;
}
