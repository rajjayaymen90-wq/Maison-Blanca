import { useEffect, useRef } from 'react';
import { flushSync } from 'react-dom';
import { useShop } from '../context/ShopContext';
import { products, productById, stockFor } from '../lib/catalog';
export default function WebMCP() {
  const state=useShop();const latest=useRef(state);latest.current=state;
  useEffect(()=>{
    const context=document.modelContext;
    if(!context?.registerTool)return;
    const lifecycle=new AbortController();
    const register=tool=>{try{Promise.resolve(context.registerTool(tool,{signal:lifecycle.signal})).catch(()=>{});}catch{}};
    register({name:'read_catalog',title:'Consulter les produits',description:'Lit le catalogue visible et les stocks, sans modifier le panier.',inputSchema:{type:'object',properties:{query:{type:'string'}},additionalProperties:false},annotations:{readOnlyHint:true,untrustedContentHint:false},execute(input){if(!input||typeof input!=='object'||input.query!==undefined&&typeof input.query!=='string')throw new Error('Recherche invalide.');return products.filter(p=>`${p.name} ${p.brand}`.toLowerCase().includes((input.query||'').toLowerCase())).map(p=>({id:p.id,name:p.name,brand:p.brand,priceCents:p.price,sizes:p.sizes,colors:p.colors,stock:p.stock}));}});
    register({name:'add_to_cart',title:'Ajouter une variante au panier',description:'Ajoute un produit au panier local et ouvre le panneau. Ne passe aucune commande et ne déclenche aucun paiement.',inputSchema:{type:'object',properties:{id:{type:'string'},size:{type:'string'},color:{type:'string'},quantity:{type:'integer',minimum:1,maximum:10}},required:['id','size','color','quantity'],additionalProperties:false},annotations:{readOnlyHint:false,untrustedContentHint:false},execute(input){const p=productById(input?.id);if(!p||!Number.isInteger(input.quantity)||input.quantity<1||input.quantity>10||stockFor(p,input.size,input.color)<input.quantity)throw new Error('Produit, variante ou quantité indisponible.');let added=false;flushSync(()=>{added=latest.current.addItem({id:p.id,size:input.size,color:input.color,quantity:input.quantity});});if(!added)throw new Error('La quantité dépasse le stock restant pour le panier.');return {added:true,cart:latest.current.cart};}});
    return()=>lifecycle.abort();
  },[]);
  return null;
}
