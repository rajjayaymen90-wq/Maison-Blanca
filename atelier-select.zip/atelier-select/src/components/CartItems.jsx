import { Link } from 'react-router-dom';
import { Minus, Plus, Trash2 } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { itemKey, money, productById, stockFor } from '../lib/catalog';
export default function CartItems() {
  const { cart, updateQuantity, removeItem, setCartOpen } = useShop();
  return <div className="cart-items">{cart.map(item => { const p = productById(item.id); const key = itemKey(item); return <article className="cart-item" key={key}>
    <Link to={`/produit/${p.slug}`} onClick={() => setCartOpen(false)}><img src={p.images[0]} alt={p.name} width="100" height="125" /></Link>
    <div className="cart-item-info"><small>{p.brand}</small><Link to={`/produit/${p.slug}`} onClick={() => setCartOpen(false)}>{p.name}</Link><p>{item.color} / {item.size}</p>
      <div className="quantity small"><button aria-label={`Diminuer la quantité de ${p.name}`} disabled={item.quantity <= 1} onClick={() => updateQuantity(key, item.quantity - 1)}><Minus size={14}/></button><span>{item.quantity}</span><button aria-label={`Augmenter la quantité de ${p.name}`} disabled={item.quantity >= Math.min(10, stockFor(p, item.size, item.color))} onClick={() => updateQuantity(key, item.quantity + 1)}><Plus size={14}/></button></div></div>
    <div className="cart-item-end"><strong>{money(p.price * item.quantity)}</strong><button className="icon-button muted" onClick={() => removeItem(key)} aria-label={`Supprimer ${p.name}`}><Trash2 size={17}/></button></div>
  </article>; })}</div>;
}
