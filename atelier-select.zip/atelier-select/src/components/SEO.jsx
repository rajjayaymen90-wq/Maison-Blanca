import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
export default function SEO({ title, description = 'Découvrez notre sélection de t-shirts, sweats et pulls de marques. Des essentiels à porter au quotidien.', noindex = false }) {
  const { pathname } = useLocation();
  useEffect(() => {
    document.title = `${title} — ATELIER SELECT`;
    const setMeta = (name, content) => { let tag = document.querySelector(`meta[name="${name}"]`); if (!tag) { tag = document.createElement('meta'); tag.name = name; document.head.appendChild(tag); } tag.content = content; };
    setMeta('description', description);
    setMeta('robots', noindex ? 'noindex, nofollow' : 'index, follow');
    let link = document.querySelector('link[rel="canonical"]');
    if (!link) { link = document.createElement('link'); link.rel = 'canonical'; document.head.appendChild(link); }
    link.href = `${(import.meta.env.VITE_SITE_URL || window.location.origin).replace(/\/$/, '')}${pathname}`;
  }, [title, description, pathname, noindex]);
  return null;
}
