import { createContext, useContext, useEffect, useState } from 'react';
import { cleanCart, itemKey, productById, stockFor, shop } from '../lib/catalog';
import { readLocal, writeLocal } from '../lib/storage';
const ShopContext = createContext(null);
export function ShopProvider({ children }) {
  const [cart, setCart] = useState(() => cleanCart(readLocal('cart', [])));
  const [promo, setPromo] = useState(() => { const p = readLocal('promo', ''); return shop.promos[p] ? p : ''; });
  const [user, setUser] = useState(() => { const u = readLocal('session', null); return u && typeof u.email === 'string' && typeof u.id === 'string' ? u : null; });
  const [toast, setToast] = useState('');
  const [cartOpen, setCartOpen] = useState(false);
  useEffect(() => { if (!writeLocal('cart', cart)) setToast('Stockage indisponible : votre panier sera conservé seulement pendant cette visite.'); }, [cart]);
  useEffect(() => { writeLocal('promo', promo); }, [promo]);
  useEffect(() => { writeLocal('session', user); }, [user]);
  useEffect(() => { if (toast) { const timer = setTimeout(() => setToast(''), 4500); return () => clearTimeout(timer); } }, [toast]);
  const addItem = (item) => {
    const p = productById(item.id);
    const max = Math.min(stockFor(p, item.size, item.color), 10);
    if (!Number.isInteger(item.quantity) || item.quantity < 1 || !max) return false;
    const existing = cart.find(i => itemKey(i) === itemKey(item));
    if ((existing?.quantity || 0) + item.quantity > max) { setToast(`Vous pouvez ajouter ${max} exemplaires maximum pour cette variante.`); return false; }
    setCart(current => cleanCart([...current, item]));
    setCartOpen(true);
    return true;
  };
  const updateQuantity = (key, quantity) => setCart(current => cleanCart(current.map(i => itemKey(i) === key ? { ...i, quantity } : i)));
  const removeItem = key => setCart(current => current.filter(i => itemKey(i) !== key));
  const clearPurchased = items => setCart(current => cleanCart(current.map(i => ({ ...i, quantity: i.quantity - (items.find(x => itemKey(x) === itemKey(i))?.quantity || 0) }))));
  return <ShopContext.Provider value={{ cart, promo, setPromo, user, setUser, toast, notify: setToast, cartOpen, setCartOpen, addItem, updateQuantity, removeItem, clearPurchased, count: cart.reduce((s, i) => s + i.quantity, 0) }}>{children}</ShopContext.Provider>;
}
export const useShop = () => useContext(ShopContext);
