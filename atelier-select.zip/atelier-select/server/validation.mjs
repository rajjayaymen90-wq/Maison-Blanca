import { createHash } from 'node:crypto';
import { productById, stockFor, itemKey, totals, shop } from '../src/lib/catalog.js';
export class HttpError extends Error { constructor(status, message) { super(message); this.status = status; } }
const fail = message => { throw new HttpError(400, message); };
export function validateCheckout(body) {
  if (!body || typeof body !== 'object' || !Array.isArray(body.items) || body.items.length < 1 || body.items.length > 40) fail('Le panier doit contenir entre 1 et 40 variantes.');
  const seen = new Set();
  const items = body.items.map(i => {
    const p = productById(i?.id);
    if (!p || !Number.isInteger(i.quantity) || i.quantity < 1 || i.quantity > 10) fail('Un article ou une quantité est invalide.');
    if (!p.sizes.includes(i.size) || !p.colors.some(c => c.name === i.color)) fail('Une variante est invalide.');
    if (i.quantity > stockFor(p,i.size,i.color)) fail(`Stock insuffisant pour ${p.name}, ${i.size}, ${i.color}.`);
    const item = { id:p.id, size:i.size, color:i.color, quantity:i.quantity };
    if (seen.has(itemKey(item))) fail('Le panier contient une variante en double.');
    seen.add(itemKey(item));
    return item;
  });
  const promo = typeof body.promo === 'string' ? body.promo.trim().toUpperCase() : '';
  if (promo && !Object.hasOwn(shop.promos,promo)) fail('Le code promotionnel est invalide.');
  const delivery = body.delivery;
  if (!Object.hasOwn(shop.shipping, delivery)) fail('Le mode de livraison est invalide.');
  const c = body.customer;
  if (!c || typeof c !== 'object') fail('Les coordonnées de livraison sont obligatoires.');
  const customer = {};
  for (const key of ['firstName','lastName','email','phone','address','address2','postalCode','city','country']) {
    if (key === 'address2' && !c[key]) { customer[key] = ''; continue; }
    if (typeof c[key] !== 'string' || !c[key].trim() || c[key].length > (key === 'email' ? 254 : 150)) fail('Vérifiez vos coordonnées de livraison.');
    customer[key] = c[key].trim();
  }
  customer.email = customer.email.toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customer.email)) fail('L’adresse e-mail est invalide.');
  if (!/^[+\d\s().-]{6,30}$/.test(customer.phone)) fail('Le numéro de téléphone est invalide.');
  if (!['FR','BE','LU','DE','ES','IT','NL','PT'].includes(customer.country)) fail('Ce pays de livraison n’est pas pris en charge.');
  if (!/^[a-zA-Z0-9 -]{3,12}$/.test(customer.postalCode)) fail('Le code postal est invalide.');
  if (typeof body.attemptId !== 'string' || !/^[a-f0-9-]{36}$/.test(body.attemptId)) fail('Identifiant de commande invalide. Rechargez la page.');
  if (typeof body.verificationToken !== 'string' || !/^[a-f0-9-]{36}$/.test(body.verificationToken)) fail('Jeton de vérification invalide. Rechargez la page.');
  return { items, promo, delivery, customer, attemptId:body.attemptId, verificationToken:body.verificationToken, amounts:totals(items,promo,delivery) };
}
export function requestFingerprint(order) {
  return createHash('sha256').update(JSON.stringify({ items:order.items, promo:order.promo, delivery:order.delivery, customer:order.customer, verificationToken:order.verificationToken })).digest('hex');
}
export const hashToken = token => createHash('sha256').update(token).digest('hex');
