import Stripe from 'stripe';
import { timingSafeEqual } from 'node:crypto';
import { HttpError, validateCheckout, requestFingerprint, hashToken } from './validation.mjs';
import { productById, shop } from '../src/lib/catalog.js';

const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'Content-Type':'application/json', 'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff' } });
function stripeClient() {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key || key.includes('REPLACE') || !key.startsWith('sk_test_')) throw new HttpError(503, 'Stripe est en attente de configuration. Renseignez une clé secrète de test côté serveur.');
  return new Stripe(key, { maxNetworkRetries:2, timeout:20000 });
}
function origin() {
  let url;
  try { url = new URL(process.env.SITE_URL); } catch { throw new HttpError(503, 'Configurez SITE_URL côté serveur.'); }
  if (url.protocol !== 'https:' && !(url.protocol === 'http:' && ['localhost','127.0.0.1'].includes(url.hostname))) throw new HttpError(503,'SITE_URL doit utiliser HTTPS.');
  if (url.username || url.password || url.pathname !== '/' || url.search || url.hash) throw new HttpError(503,'SITE_URL doit contenir uniquement l’origine du site.');
  return url.origin;
}
async function withErrors(fn) {
  try { return await fn(); } catch (e) {
    if (e instanceof HttpError) return json({ error:e.message },e.status);
    console.error('API error', e.type || e.name, e.code || 'unexpected');
    return json({ error:'Le service de paiement est temporairement indisponible. Réessayez dans un instant.' },502);
  }
}
async function limitedBody(req) {
  if (Number(req.headers.get('content-length')) > 24000) throw new HttpError(413,'Requête trop volumineuse.');
  const text = await req.text();
  if (Buffer.byteLength(text) > 24000) throw new HttpError(413,'Requête trop volumineuse.');
  try { return JSON.parse(text); } catch { throw new HttpError(400,'Le corps JSON est invalide.'); }
}
export async function checkout(req) {
  if (req.method !== 'POST') return json({error:'Méthode non autorisée.'},405);
  return withErrors(async () => {
    const site = origin();
    const requestOrigin = req.headers.get('origin');
    if (requestOrigin && requestOrigin !== site) throw new HttpError(403,'Origine non autorisée.');
    if (!req.headers.get('content-type')?.includes('application/json')) throw new HttpError(415,'Utilisez application/json.');
    const order = validateCheckout(await limitedBody(req));
    const stripe = stripeClient();
    const percent = shop.promos[order.promo]?.percent || 0;
    const shipping = shop.shipping[order.delivery];
    const c = order.customer;
    const session = await stripe.checkout.sessions.create({
      mode:'payment', payment_method_types:['card'], locale:'fr', customer_email:c.email,
      client_reference_id:order.attemptId,
      line_items:order.items.map(i => { const p = productById(i.id); return {
        quantity:i.quantity,
        price_data:{ currency:'eur', unit_amount:Math.round(p.price * (100 - percent) / 100), product_data:{ name:`${p.brand} · ${p.name}`, description:`${i.color} / ${i.size}${order.promo ? ` · ${order.promo} : −${percent} % inclus` : ''}`, metadata:{ product_id:p.id, size:i.size, color:i.color } } }
      }; }),
      shipping_options:[{ shipping_rate_data:{ type:'fixed_amount', fixed_amount:{ amount:order.amounts.shipping, currency:'eur' }, display_name:shipping.label, delivery_estimate:{ minimum:{ unit:'business_day', value:order.delivery === 'express' ? 1 : 3 }, maximum:{ unit:'business_day', value:order.delivery === 'express' ? 2 : 5 } } } }],
      payment_intent_data:{ shipping:{ name:`${c.firstName} ${c.lastName}`, phone:c.phone, address:{ line1:c.address, line2:c.address2, postal_code:c.postalCode, city:c.city, country:c.country } } },
      metadata:{ verification_hash:hashToken(order.verificationToken), delivery:order.delivery, promo:order.promo },
      success_url:`${site}/confirmation?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url:`${site}/commande?annule=1`
    }, { idempotencyKey:`checkout-${order.attemptId}-${requestFingerprint(order)}` });
    return json({ id:session.id, url:session.url });
  });
}
export async function session(req) {
  if (req.method !== 'GET') return json({error:'Méthode non autorisée.'},405);
  return withErrors(async () => {
    const id = new URL(req.url).searchParams.get('session_id');
    const token = req.headers.get('authorization')?.replace(/^Bearer /,'');
    if (!id || !/^cs_test_[a-zA-Z0-9]+$/.test(id) || !token || !/^[a-f0-9-]{36}$/.test(token)) throw new HttpError(400,'Lien de confirmation incomplet. Revenez depuis la commande sur cet appareil.');
    const stripe = stripeClient();
    const result = await stripe.checkout.sessions.retrieve(id);
    const expected = result.metadata?.verification_hash || '';
    const actual = hashToken(token);
    if (expected.length !== actual.length || !timingSafeEqual(Buffer.from(expected),Buffer.from(actual))) throw new HttpError(403,'Cette commande ne peut pas être consultée depuis cette session.');
    if (result.status !== 'complete' || result.payment_status !== 'paid') return json({ paid:false, status:result.status },202);
    const lines = await stripe.checkout.sessions.listLineItems(id,{ limit:100, expand:['data.price.product'] });
    const items = lines.data.map(l => ({ id:l.price.product.metadata.product_id, name:l.description, size:l.price.product.metadata.size, color:l.price.product.metadata.color, quantity:l.quantity, price:l.price.unit_amount }));
    return json({ paid:true, id:result.id, number:`AS-${result.id.slice(-8).toUpperCase()}`, date:new Date(result.created * 1000).toISOString(), items, total:result.amount_total, shipping:result.total_details.amount_shipping, discount:0, merchandise:result.amount_subtotal, promo:result.metadata.promo, delivery:result.metadata.delivery, mode:'stripe-test' });
  });
}
export async function webhook(req) {
  if (req.method !== 'POST') return json({error:'Méthode non autorisée.'},405);
  return withErrors(async () => {
    const stripe = stripeClient();
    const secret = process.env.STRIPE_WEBHOOK_SECRET;
    if (!secret || secret.includes('REPLACE')) throw new HttpError(503,'Webhook non configuré.');
    const signature = req.headers.get('stripe-signature');
    if (!signature) throw new HttpError(400,'Signature absente.');
    const raw = Buffer.from(await req.arrayBuffer());
    if (raw.length > 1000000) throw new HttpError(413,'Événement trop volumineux.');
    let event;
    try { event = stripe.webhooks.constructEvent(raw,signature,secret); } catch { throw new HttpError(400,'Signature invalide.'); }
    if (['checkout.session.completed','checkout.session.async_payment_succeeded'].includes(event.type) && event.data.object.payment_status === 'paid') {
      // TEST SCAFFOLD: persist the event/session in a database with a UNIQUE session_id,
      // reserve/decrement variant inventory in the same transaction, then enqueue fulfillment.
      // Do not ship goods from the browser confirmation page. This endpoint does NOT fulfill orders.
      console.info('Verified Stripe test event; manual fulfillment only',event.id,event.data.object.id);
    }
    return json({ received:true, fulfillment:'manual-test-only' });
  });
}
