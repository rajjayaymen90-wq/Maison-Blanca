export function vercelAdapter(handler) {
  return async (req,res) => {
    try {
      const chunks = [];
      let size = 0;
      for await (const chunk of req) { const buffer = Buffer.from(chunk); size += buffer.length; if (size > 1000000) { res.statusCode=413; res.end('Payload too large'); return; } chunks.push(buffer); }
      const headers = new Headers();
      for (const [key,value] of Object.entries(req.headers)) if (value !== undefined) headers.set(key,Array.isArray(value) ? value.join(',') : value);
      const request = new Request(`http://internal${req.url}`,{ method:req.method, headers, ...(req.method !== 'GET' && req.method !== 'HEAD' ? { body:Buffer.concat(chunks) } : {}) });
      const response = await handler(request);
      res.statusCode=response.status;
      response.headers.forEach((v,k) => res.setHeader(k,v));
      res.end(Buffer.from(await response.arrayBuffer()));
    } catch { res.statusCode=500; res.setHeader('Content-Type','application/json'); res.end(JSON.stringify({error:'Erreur interne du serveur.'})); }
  };
}
