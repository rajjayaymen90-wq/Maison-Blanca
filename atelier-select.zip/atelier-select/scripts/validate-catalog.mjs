import { products,shop } from '../src/lib/catalog.js';
const errors=[];const ids=new Set();const slugs=new Set();
for(const p of products){
  const error=message=>errors.push(`${p.id || '(sans identifiant)'} : ${message}`);
  if(!p.id || ids.has(p.id)) error('identifiant manquant ou dupliqué');ids.add(p.id);
  if(!/^[a-z0-9-]+$/.test(p.slug) || slugs.has(p.slug)) error('slug invalide ou dupliqué');slugs.add(p.slug);
  for(const k of ['name','brand','description','material','fit']) if(typeof p[k] !== 'string' || !p[k].trim()) error(`${k} requis`);
  if(!Number.isInteger(p.price) || p.price < 50) error('prix en centimes, entier >= 50');
  if(p.oldPrice !== undefined && (!Number.isInteger(p.oldPrice) || p.oldPrice <= p.price)) error('oldPrice doit être supérieur au prix actuel');
  if(!['t-shirts','pulls'].includes(p.category)) error('catégorie invalide');
  if(!Array.isArray(p.images) || !p.images.length || p.images.some(i=>typeof i !== 'string' || !/^(https:\/\/|\/images\/)/.test(i))) error('images HTTPS ou /images/ requises');
  if(!Array.isArray(p.sizes) || !p.sizes.length) {error('tailles requises');continue;}
  if(!Array.isArray(p.colors) || !p.colors.length) {error('couleurs requises');continue;}
  for(const c of p.colors){if(!c.name || !/^#[a-fA-F0-9]{6}$/.test(c.hex)) error('couleur invalide');for(const size of p.sizes){const stock=p.stock?.[c.name]?.[size];if(!Number.isInteger(stock) || stock < 0) error(`stock invalide pour ${c.name}/${size}`);}}
  if(!Number.isFinite(Date.parse(p.createdAt))) error('date createdAt invalide');
  if(!Number.isFinite(p.popularity)) error('popularité numérique requise');
}
if(!Number.isInteger(shop.freeShippingThreshold) || shop.freeShippingThreshold<0) errors.push('Seuil de livraison invalide');
for(const p of Object.values(shop.promos)) if(!Number.isInteger(p.percent) || p.percent<1 || p.percent>90) errors.push('Les remises doivent être comprises entre 1 et 90 %');
if(errors.length){console.error(errors.join('\n'));process.exit(1);}
console.log(`Catalogue validé : ${products.length} produits, ${new Set(products.map(p=>p.brand)).size} marques.`);
